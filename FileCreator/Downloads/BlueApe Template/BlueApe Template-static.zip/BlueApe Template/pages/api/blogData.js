 import blogDocument from '../../BlogDocument.json';

       export default (req, res) => {
         res.status(200).json(blogDocument)
       }