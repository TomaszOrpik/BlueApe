webpackHotUpdate_N_E("pages/[pid]",{

/***/ "./pages/[pid].js":
/*!************************!*\
  !*** ./pages/[pid].js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return handler; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swr */ "./node_modules/swr/esm/index.js");
/* harmony import */ var _Layout_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Layout/layout */ "./Layout/layout.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! unfetch */ "./node_modules/next/dist/build/polyfills/fetch/index.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\Users\\sycho\\Desktop\\Nowy folder\\blogtemplate\\pages\\[pid].js",
    _s = $RefreshSig$();








var main = function main(page) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "jsx-2916991593",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
      src: page.ImageUrl,
      className: "jsx-2916991593" + " " + "postImage"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 5
    }, this), page.Content, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
      id: "2916991593",
      children: ".postHeaders.jsx-2916991593{left:80px;margin-left:25%;width:50%;margin-top:-380px;z-index:10;}.pageHeader.jsx-2916991593{width:calc(100% - 60px);padding-right:60px;height:50%;}.postImage.jsx-2916991593{width:100%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcc3ljaG9cXERlc2t0b3BcXE5vd3kgZm9sZGVyXFxibG9ndGVtcGxhdGVcXHBhZ2VzXFxbcGlkXS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFnQmdCLEFBR21CLEFBT2MsQUFNYixVQVpLLENBYXBCLGFBTnVCLEVBTlQsVUFDUSxPQU1QLFdBTEEsQUFNZixXQUxBIiwiZmlsZSI6IkM6XFxVc2Vyc1xcc3ljaG9cXERlc2t0b3BcXE5vd3kgZm9sZGVyXFxibG9ndGVtcGxhdGVcXHBhZ2VzXFxbcGlkXS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB1c2VTV1IgZnJvbSAnc3dyJ1xyXG5pbXBvcnQgZ2VuZXJhdGVQYWdlIGZyb20gJy4uL0xheW91dC9sYXlvdXQnXHJcbmltcG9ydCBmZXRjaCBmcm9tICd1bmZldGNoJ1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xyXG5cclxuY29uc3QgbWFpbiA9IGZ1bmN0aW9uKHBhZ2UpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgIDxpbWcgY2xhc3NOYW1lPVwicG9zdEltYWdlXCIgc3JjPXtwYWdlLkltYWdlVXJsfSAvPlxyXG4gICAgey8qPGRpdiBjbGFzc05hbWU9XCJwb3N0SGVhZGVyc1wiPlxyXG4gICAgICAgIDxoMyBzdHlsZT1cImZvbnQtc2l6ZTogMzVweDsgZm9udC13ZWlnaHQ6IDcwMDsgY29sb3I6IEAoYmxvZ01vZGVsLnByaW1hcnlDb2xvcilcIj57cGFnZS5DYXRlZ29yaWVzLmpvaW4oJywgJyl9PC9oMz5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZHluYW1pY0NvbG9yXCIgc3R5bGU9XCJmb250LXNpemU6IDEyMHB4OyBmb250LXdlaWdodDogNzAwO1wiPntwYWdlLlRpdGxlfTwvaDE+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cImR5bmFtaWNDb2xvclwiIHN0eWxlPVwiZm9udC1zaXplOiAyNXB4OyBmb250LXdlaWdodDogNzAwO1wiPntwYWdlLkRhdGV9PC9oMz5cclxuICA8L2Rpdj4qL31cclxuICAgIHtwYWdlLkNvbnRlbnR9XHJcbiAgICA8c3R5bGUganN4PntgXHJcbiAgICAgICAucG9zdEhlYWRlcnMge1xyXG4gICAgICAgIGxlZnQ6IDgwcHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDI1JTtcclxuICAgICAgICB3aWR0aDogNTAlO1xyXG4gICAgICAgIG1hcmdpbi10b3A6IC0zODBweDtcclxuICAgICAgICB6LWluZGV4OiAxMDtcclxuICAgIH1cclxuICAgIC5wYWdlSGVhZGVyIHtcclxuICAgICAgICB3aWR0aDogY2FsYygxMDAlIC0gNjBweCk7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDogNjBweDtcclxuICAgICAgICBoZWlnaHQ6IDUwJTtcclxuICAgIH1cclxuXHJcbiAgICAucG9zdEltYWdlIHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIGB9PC9zdHlsZT5cclxuICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICBjb25zdCBmZXRjaGVyID0gdXJsID0+IGZldGNoKHVybCkudGhlbihyID0+IHIuanNvbigpKTtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSB1c2VTV1IoJy9hcGkvYmxvZ0RhdGEnLCBmZXRjaGVyKTtcclxuXHJcbiAgaWYgKGVycm9yKSByZXR1cm4gPGRpdj5mYWlsZWQgdG8gbG9hZDwvZGl2PlxyXG4gIGlmICghZGF0YSkgcmV0dXJuIDxkaXY+bG9hZGluZy4uLjwvZGl2PlxyXG5cclxuICBjb25zdCB7IHBpZCB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gIGxldCBwYWdlID0gZGF0YS5CbG9nRG9jdW1lbnQuUGFnZXMuZmluZChwID0+IHAuVGl0bGUgPT09IHBpZCk7XHJcbiAgY29uc29sZS5sb2cocGFnZSk7XHJcbiAgaWYgKCFwYWdlKSBwYWdlID0gZGF0YS5CbG9nRG9jdW1lbnQuUG9zdHMuZmluZChwID0+IHAuVGl0bGUgPT09IHBpZCk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XHJcbiAgICAgICAge2dlbmVyYXRlUGFnZShkYXRhLCBtYWluKHBhZ2UpKX1cclxuICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH0iXX0= */\n/*@ sourceURL=C:\\\\Users\\\\sycho\\\\Desktop\\\\Nowy folder\\\\blogtemplate\\\\pages\\\\[pid].js */"
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, this);
};

function handler(req, res) {
  _s();

  var fetcher = function fetcher(url) {
    return unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url).then(function (r) {
      return r.json();
    });
  };

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"])();

  var _useSWR = Object(swr__WEBPACK_IMPORTED_MODULE_2__["default"])('/api/blogData', fetcher),
      data = _useSWR.data,
      error = _useSWR.error;

  if (error) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "failed to load"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 44,
    columnNumber: 21
  }, this);
  if (!data) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "loading..."
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 21
  }, this);
  var pid = router.query.pid;
  var page = data.BlogDocument.Pages.find(function (p) {
    return p.Title === pid;
  });
  console.log(page);
  if (!page) page = data.BlogDocument.Posts.find(function (p) {
    return p.Title === pid;
  });
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default.a.container,
    children: Object(_Layout_layout__WEBPACK_IMPORTED_MODULE_3__["default"])(data, main(page))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 52,
    columnNumber: 7
  }, this);
}

_s(handler, "F2OQGCTB9lgwThKfzWI7sczFgbA=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"], swr__WEBPACK_IMPORTED_MODULE_2__["default"]];
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvW3BpZF0uanMiXSwibmFtZXMiOlsibWFpbiIsInBhZ2UiLCJJbWFnZVVybCIsIkNvbnRlbnQiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiZmV0Y2hlciIsInVybCIsImZldGNoIiwidGhlbiIsInIiLCJqc29uIiwicm91dGVyIiwidXNlUm91dGVyIiwidXNlU1dSIiwiZGF0YSIsImVycm9yIiwicGlkIiwicXVlcnkiLCJCbG9nRG9jdW1lbnQiLCJQYWdlcyIsImZpbmQiLCJwIiwiVGl0bGUiLCJjb25zb2xlIiwibG9nIiwiUG9zdHMiLCJzdHlsZXMiLCJjb250YWluZXIiLCJnZW5lcmF0ZVBhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBTUEsSUFBSSxHQUFHLFNBQVBBLElBQU8sQ0FBU0MsSUFBVCxFQUFlO0FBQzFCLHNCQUNFO0FBQUE7QUFBQSw0QkFDQTtBQUEyQixTQUFHLEVBQUVBLElBQUksQ0FBQ0MsUUFBckM7QUFBQSwwQ0FBZTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFEQSxFQU9DRCxJQUFJLENBQUNFLE9BUE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUE2QkQsQ0E5QkQ7O0FBZ0NlLFNBQVNDLE9BQVQsQ0FBaUJDLEdBQWpCLEVBQXNCQyxHQUF0QixFQUEyQjtBQUFBOztBQUN4QyxNQUFNQyxPQUFPLEdBQUcsU0FBVkEsT0FBVSxDQUFBQyxHQUFHO0FBQUEsV0FBSUMsOENBQUssQ0FBQ0QsR0FBRCxDQUFMLENBQVdFLElBQVgsQ0FBZ0IsVUFBQUMsQ0FBQztBQUFBLGFBQUlBLENBQUMsQ0FBQ0MsSUFBRixFQUFKO0FBQUEsS0FBakIsQ0FBSjtBQUFBLEdBQW5COztBQUNBLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7O0FBRndDLGdCQUdoQkMsbURBQU0sQ0FBQyxlQUFELEVBQWtCUixPQUFsQixDQUhVO0FBQUEsTUFHaENTLElBSGdDLFdBR2hDQSxJQUhnQztBQUFBLE1BRzFCQyxLQUgwQixXQUcxQkEsS0FIMEI7O0FBS3hDLE1BQUlBLEtBQUosRUFBVyxvQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBQ1gsTUFBSSxDQUFDRCxJQUFMLEVBQVcsb0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQU42QixNQVFoQ0UsR0FSZ0MsR0FReEJMLE1BQU0sQ0FBQ00sS0FSaUIsQ0FRaENELEdBUmdDO0FBU3hDLE1BQUlqQixJQUFJLEdBQUdlLElBQUksQ0FBQ0ksWUFBTCxDQUFrQkMsS0FBbEIsQ0FBd0JDLElBQXhCLENBQTZCLFVBQUFDLENBQUM7QUFBQSxXQUFJQSxDQUFDLENBQUNDLEtBQUYsS0FBWU4sR0FBaEI7QUFBQSxHQUE5QixDQUFYO0FBQ0FPLFNBQU8sQ0FBQ0MsR0FBUixDQUFZekIsSUFBWjtBQUNBLE1BQUksQ0FBQ0EsSUFBTCxFQUFXQSxJQUFJLEdBQUdlLElBQUksQ0FBQ0ksWUFBTCxDQUFrQk8sS0FBbEIsQ0FBd0JMLElBQXhCLENBQTZCLFVBQUFDLENBQUM7QUFBQSxXQUFJQSxDQUFDLENBQUNDLEtBQUYsS0FBWU4sR0FBaEI7QUFBQSxHQUE5QixDQUFQO0FBQ1Qsc0JBQ0U7QUFBSyxhQUFTLEVBQUVVLDhEQUFNLENBQUNDLFNBQXZCO0FBQUEsY0FDR0MsOERBQVksQ0FBQ2QsSUFBRCxFQUFPaEIsSUFBSSxDQUFDQyxJQUFELENBQVg7QUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFLRDs7R0FqQnFCRyxPO1VBRVBVLHFELEVBQ1NDLDJDIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL1twaWRdLjk3ZWVlMDliMGFkZDQyMDU3MjkwLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdXNlU1dSIGZyb20gJ3N3cidcclxuaW1wb3J0IGdlbmVyYXRlUGFnZSBmcm9tICcuLi9MYXlvdXQvbGF5b3V0J1xyXG5pbXBvcnQgZmV0Y2ggZnJvbSAndW5mZXRjaCdcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL0hvbWUubW9kdWxlLmNzcydcclxuXHJcbmNvbnN0IG1haW4gPSBmdW5jdGlvbihwYWdlKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICA8aW1nIGNsYXNzTmFtZT1cInBvc3RJbWFnZVwiIHNyYz17cGFnZS5JbWFnZVVybH0gLz5cclxuICAgIHsvKjxkaXYgY2xhc3NOYW1lPVwicG9zdEhlYWRlcnNcIj5cclxuICAgICAgICA8aDMgc3R5bGU9XCJmb250LXNpemU6IDM1cHg7IGZvbnQtd2VpZ2h0OiA3MDA7IGNvbG9yOiBAKGJsb2dNb2RlbC5wcmltYXJ5Q29sb3IpXCI+e3BhZ2UuQ2F0ZWdvcmllcy5qb2luKCcsICcpfTwvaDM+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cImR5bmFtaWNDb2xvclwiIHN0eWxlPVwiZm9udC1zaXplOiAxMjBweDsgZm9udC13ZWlnaHQ6IDcwMDtcIj57cGFnZS5UaXRsZX08L2gxPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJkeW5hbWljQ29sb3JcIiBzdHlsZT1cImZvbnQtc2l6ZTogMjVweDsgZm9udC13ZWlnaHQ6IDcwMDtcIj57cGFnZS5EYXRlfTwvaDM+XHJcbiAgPC9kaXY+Ki99XHJcbiAgICB7cGFnZS5Db250ZW50fVxyXG4gICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgLnBvc3RIZWFkZXJzIHtcclxuICAgICAgICBsZWZ0OiA4MHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyNSU7XHJcbiAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgICBtYXJnaW4tdG9wOiAtMzgwcHg7XHJcbiAgICAgICAgei1pbmRleDogMTA7XHJcbiAgICB9XHJcbiAgICAucGFnZUhlYWRlciB7XHJcbiAgICAgICAgd2lkdGg6IGNhbGMoMTAwJSAtIDYwcHgpO1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDYwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA1MCU7XHJcbiAgICB9XHJcblxyXG4gICAgLnBvc3RJbWFnZSB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbiAgICBgfTwvc3R5bGU+XHJcbiAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgY29uc3QgZmV0Y2hlciA9IHVybCA9PiBmZXRjaCh1cmwpLnRoZW4ociA9PiByLmpzb24oKSk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gdXNlU1dSKCcvYXBpL2Jsb2dEYXRhJywgZmV0Y2hlcik7XHJcblxyXG4gIGlmIChlcnJvcikgcmV0dXJuIDxkaXY+ZmFpbGVkIHRvIGxvYWQ8L2Rpdj5cclxuICBpZiAoIWRhdGEpIHJldHVybiA8ZGl2PmxvYWRpbmcuLi48L2Rpdj5cclxuXHJcbiAgY29uc3QgeyBwaWQgfSA9IHJvdXRlci5xdWVyeTtcclxuICBsZXQgcGFnZSA9IGRhdGEuQmxvZ0RvY3VtZW50LlBhZ2VzLmZpbmQocCA9PiBwLlRpdGxlID09PSBwaWQpO1xyXG4gIGNvbnNvbGUubG9nKHBhZ2UpO1xyXG4gIGlmICghcGFnZSkgcGFnZSA9IGRhdGEuQmxvZ0RvY3VtZW50LlBvc3RzLmZpbmQocCA9PiBwLlRpdGxlID09PSBwaWQpO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxyXG4gICAgICAgIHtnZW5lcmF0ZVBhZ2UoZGF0YSwgbWFpbihwYWdlKSl9XHJcbiAgICA8L2Rpdj5cclxuICAgIClcclxuICB9Il0sInNvdXJjZVJvb3QiOiIifQ==