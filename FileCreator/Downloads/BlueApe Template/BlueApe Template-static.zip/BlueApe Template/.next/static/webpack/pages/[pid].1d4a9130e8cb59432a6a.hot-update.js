webpackHotUpdate_N_E("pages/[pid]",{

/***/ "./pages/[pid].js":
/*!************************!*\
  !*** ./pages/[pid].js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return handler; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swr */ "./node_modules/swr/esm/index.js");
/* harmony import */ var _Layout_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Layout/layout */ "./Layout/layout.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! unfetch */ "./node_modules/next/dist/build/polyfills/fetch/index.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\Users\\sycho\\Desktop\\Nowy folder\\blogtemplate\\pages\\[pid].js",
    _s = $RefreshSig$();








var main = function main(page) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "jsx-2916991593",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
      src: page.ImageUrl,
      className: "jsx-2916991593" + " " + "postImage"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 5
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "jsx-2916991593" + " " + "postHeaders",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        style: "font-size: 35px; font-weight: 700; color: @(blogModel.primaryColor)",
        className: "jsx-2916991593",
        children: page.Categories.join(', ')
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
        style: "font-size: 120px; font-weight: 700;",
        className: "jsx-2916991593" + " " + "dynamicColor",
        children: page.Title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        style: "font-size: 25px; font-weight: 700;",
        className: "jsx-2916991593" + " " + "dynamicColor",
        children: page.Date
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 5
    }, this), page.Content, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
      id: "2916991593",
      children: ".postHeaders.jsx-2916991593{left:80px;margin-left:25%;width:50%;margin-top:-380px;z-index:10;}.pageHeader.jsx-2916991593{width:calc(100% - 60px);padding-right:60px;height:50%;}.postImage.jsx-2916991593{width:100%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcc3ljaG9cXERlc2t0b3BcXE5vd3kgZm9sZGVyXFxibG9ndGVtcGxhdGVcXHBhZ2VzXFxbcGlkXS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFnQmdCLEFBR21CLEFBT2MsQUFNYixVQVpLLENBYXBCLGFBTnVCLEVBTlQsVUFDUSxPQU1QLFdBTEEsQUFNZixXQUxBIiwiZmlsZSI6IkM6XFxVc2Vyc1xcc3ljaG9cXERlc2t0b3BcXE5vd3kgZm9sZGVyXFxibG9ndGVtcGxhdGVcXHBhZ2VzXFxbcGlkXS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB1c2VTV1IgZnJvbSAnc3dyJ1xyXG5pbXBvcnQgZ2VuZXJhdGVQYWdlIGZyb20gJy4uL0xheW91dC9sYXlvdXQnXHJcbmltcG9ydCBmZXRjaCBmcm9tICd1bmZldGNoJ1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xyXG5cclxuY29uc3QgbWFpbiA9IGZ1bmN0aW9uKHBhZ2UpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgIDxpbWcgY2xhc3NOYW1lPVwicG9zdEltYWdlXCIgc3JjPXtwYWdlLkltYWdlVXJsfSAvPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwb3N0SGVhZGVyc1wiPlxyXG4gICAgICAgIDxoMyBzdHlsZT1cImZvbnQtc2l6ZTogMzVweDsgZm9udC13ZWlnaHQ6IDcwMDsgY29sb3I6IEAoYmxvZ01vZGVsLnByaW1hcnlDb2xvcilcIj57cGFnZS5DYXRlZ29yaWVzLmpvaW4oJywgJyl9PC9oMz5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZHluYW1pY0NvbG9yXCIgc3R5bGU9XCJmb250LXNpemU6IDEyMHB4OyBmb250LXdlaWdodDogNzAwO1wiPntwYWdlLlRpdGxlfTwvaDE+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cImR5bmFtaWNDb2xvclwiIHN0eWxlPVwiZm9udC1zaXplOiAyNXB4OyBmb250LXdlaWdodDogNzAwO1wiPntwYWdlLkRhdGV9PC9oMz5cclxuICA8L2Rpdj5cclxuICAgIHtwYWdlLkNvbnRlbnR9XHJcbiAgICA8c3R5bGUganN4PntgXHJcbiAgICAgICAucG9zdEhlYWRlcnMge1xyXG4gICAgICAgIGxlZnQ6IDgwcHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDI1JTtcclxuICAgICAgICB3aWR0aDogNTAlO1xyXG4gICAgICAgIG1hcmdpbi10b3A6IC0zODBweDtcclxuICAgICAgICB6LWluZGV4OiAxMDtcclxuICAgIH1cclxuICAgIC5wYWdlSGVhZGVyIHtcclxuICAgICAgICB3aWR0aDogY2FsYygxMDAlIC0gNjBweCk7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDogNjBweDtcclxuICAgICAgICBoZWlnaHQ6IDUwJTtcclxuICAgIH1cclxuXHJcbiAgICAucG9zdEltYWdlIHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIGB9PC9zdHlsZT5cclxuICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICBjb25zdCBmZXRjaGVyID0gdXJsID0+IGZldGNoKHVybCkudGhlbihyID0+IHIuanNvbigpKTtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSB1c2VTV1IoJy9hcGkvYmxvZ0RhdGEnLCBmZXRjaGVyKTtcclxuXHJcbiAgaWYgKGVycm9yKSByZXR1cm4gPGRpdj5mYWlsZWQgdG8gbG9hZDwvZGl2PlxyXG4gIGlmICghZGF0YSkgcmV0dXJuIDxkaXY+bG9hZGluZy4uLjwvZGl2PlxyXG5cclxuICBjb25zdCB7IHBpZCB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gIGxldCBwYWdlID0gZGF0YS5CbG9nRG9jdW1lbnQuUGFnZXMuZmluZChwID0+IHAuVGl0bGUgPT09IHBpZCk7XHJcbiAgaWYgKCFwYWdlKSBwYWdlID0gZGF0YS5CbG9nRG9jdW1lbnQuUG9zdHMuZmluZChwID0+IHAuVGl0bGUgPT09IHBpZCk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XHJcbiAgICAgICAge2dlbmVyYXRlUGFnZShkYXRhLCBtYWluKHBhZ2UpKX1cclxuICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH0iXX0= */\n/*@ sourceURL=C:\\\\Users\\\\sycho\\\\Desktop\\\\Nowy folder\\\\blogtemplate\\\\pages\\\\[pid].js */"
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, this);
};

function handler(req, res) {
  _s();

  var fetcher = function fetcher(url) {
    return unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url).then(function (r) {
      return r.json();
    });
  };

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"])();

  var _useSWR = Object(swr__WEBPACK_IMPORTED_MODULE_2__["default"])('/api/blogData', fetcher),
      data = _useSWR.data,
      error = _useSWR.error;

  if (error) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "failed to load"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 44,
    columnNumber: 21
  }, this);
  if (!data) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "loading..."
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 21
  }, this);
  var pid = router.query.pid;
  var page = data.BlogDocument.Pages.find(function (p) {
    return p.Title === pid;
  });
  if (!page) page = data.BlogDocument.Posts.find(function (p) {
    return p.Title === pid;
  });
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default.a.container,
    children: Object(_Layout_layout__WEBPACK_IMPORTED_MODULE_3__["default"])(data, main(page))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 51,
    columnNumber: 7
  }, this);
}

_s(handler, "F2OQGCTB9lgwThKfzWI7sczFgbA=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"], swr__WEBPACK_IMPORTED_MODULE_2__["default"]];
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvW3BpZF0uanMiXSwibmFtZXMiOlsibWFpbiIsInBhZ2UiLCJJbWFnZVVybCIsIkNhdGVnb3JpZXMiLCJqb2luIiwiVGl0bGUiLCJEYXRlIiwiQ29udGVudCIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJmZXRjaGVyIiwidXJsIiwiZmV0Y2giLCJ0aGVuIiwiciIsImpzb24iLCJyb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJ1c2VTV1IiLCJkYXRhIiwiZXJyb3IiLCJwaWQiLCJxdWVyeSIsIkJsb2dEb2N1bWVudCIsIlBhZ2VzIiwiZmluZCIsInAiLCJQb3N0cyIsInN0eWxlcyIsImNvbnRhaW5lciIsImdlbmVyYXRlUGFnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxJQUFNQSxJQUFJLEdBQUcsU0FBUEEsSUFBTyxDQUFTQyxJQUFULEVBQWU7QUFDMUIsc0JBQ0U7QUFBQTtBQUFBLDRCQUNBO0FBQTJCLFNBQUcsRUFBRUEsSUFBSSxDQUFDQyxRQUFyQztBQUFBLDBDQUFlO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURBLGVBRUE7QUFBQSwwQ0FBZSxhQUFmO0FBQUEsOEJBQ0k7QUFBSSxhQUFLLEVBQUMscUVBQVY7QUFBQTtBQUFBLGtCQUFpRkQsSUFBSSxDQUFDRSxVQUFMLENBQWdCQyxJQUFoQixDQUFxQixJQUFyQjtBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREosZUFFSTtBQUE2QixhQUFLLEVBQUMscUNBQW5DO0FBQUEsNENBQWMsY0FBZDtBQUFBLGtCQUEwRUgsSUFBSSxDQUFDSTtBQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkosZUFHSTtBQUE2QixhQUFLLEVBQUMsb0NBQW5DO0FBQUEsNENBQWMsY0FBZDtBQUFBLGtCQUF5RUosSUFBSSxDQUFDSztBQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkEsRUFPQ0wsSUFBSSxDQUFDTSxPQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBNkJELENBOUJEOztBQWdDZSxTQUFTQyxPQUFULENBQWlCQyxHQUFqQixFQUFzQkMsR0FBdEIsRUFBMkI7QUFBQTs7QUFDeEMsTUFBTUMsT0FBTyxHQUFHLFNBQVZBLE9BQVUsQ0FBQUMsR0FBRztBQUFBLFdBQUlDLDhDQUFLLENBQUNELEdBQUQsQ0FBTCxDQUFXRSxJQUFYLENBQWdCLFVBQUFDLENBQUM7QUFBQSxhQUFJQSxDQUFDLENBQUNDLElBQUYsRUFBSjtBQUFBLEtBQWpCLENBQUo7QUFBQSxHQUFuQjs7QUFDQSxNQUFNQyxNQUFNLEdBQUdDLDZEQUFTLEVBQXhCOztBQUZ3QyxnQkFHaEJDLG1EQUFNLENBQUMsZUFBRCxFQUFrQlIsT0FBbEIsQ0FIVTtBQUFBLE1BR2hDUyxJQUhnQyxXQUdoQ0EsSUFIZ0M7QUFBQSxNQUcxQkMsS0FIMEIsV0FHMUJBLEtBSDBCOztBQUt4QyxNQUFJQSxLQUFKLEVBQVcsb0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNYLE1BQUksQ0FBQ0QsSUFBTCxFQUFXLG9CQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFONkIsTUFRaENFLEdBUmdDLEdBUXhCTCxNQUFNLENBQUNNLEtBUmlCLENBUWhDRCxHQVJnQztBQVN4QyxNQUFJckIsSUFBSSxHQUFHbUIsSUFBSSxDQUFDSSxZQUFMLENBQWtCQyxLQUFsQixDQUF3QkMsSUFBeEIsQ0FBNkIsVUFBQUMsQ0FBQztBQUFBLFdBQUlBLENBQUMsQ0FBQ3RCLEtBQUYsS0FBWWlCLEdBQWhCO0FBQUEsR0FBOUIsQ0FBWDtBQUNBLE1BQUksQ0FBQ3JCLElBQUwsRUFBV0EsSUFBSSxHQUFHbUIsSUFBSSxDQUFDSSxZQUFMLENBQWtCSSxLQUFsQixDQUF3QkYsSUFBeEIsQ0FBNkIsVUFBQUMsQ0FBQztBQUFBLFdBQUlBLENBQUMsQ0FBQ3RCLEtBQUYsS0FBWWlCLEdBQWhCO0FBQUEsR0FBOUIsQ0FBUDtBQUNULHNCQUNFO0FBQUssYUFBUyxFQUFFTyw4REFBTSxDQUFDQyxTQUF2QjtBQUFBLGNBQ0dDLDhEQUFZLENBQUNYLElBQUQsRUFBT3BCLElBQUksQ0FBQ0MsSUFBRCxDQUFYO0FBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBS0Q7O0dBaEJxQk8sTztVQUVQVSxxRCxFQUNTQywyQyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9bcGlkXS4xZDRhOTEzMGU4Y2I1OTQzMmE2YS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHVzZVNXUiBmcm9tICdzd3InXHJcbmltcG9ydCBnZW5lcmF0ZVBhZ2UgZnJvbSAnLi4vTGF5b3V0L2xheW91dCdcclxuaW1wb3J0IGZldGNoIGZyb20gJ3VuZmV0Y2gnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXHJcblxyXG5jb25zdCBtYWluID0gZnVuY3Rpb24ocGFnZSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgPGltZyBjbGFzc05hbWU9XCJwb3N0SW1hZ2VcIiBzcmM9e3BhZ2UuSW1hZ2VVcmx9IC8+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3RIZWFkZXJzXCI+XHJcbiAgICAgICAgPGgzIHN0eWxlPVwiZm9udC1zaXplOiAzNXB4OyBmb250LXdlaWdodDogNzAwOyBjb2xvcjogQChibG9nTW9kZWwucHJpbWFyeUNvbG9yKVwiPntwYWdlLkNhdGVnb3JpZXMuam9pbignLCAnKX08L2gzPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJkeW5hbWljQ29sb3JcIiBzdHlsZT1cImZvbnQtc2l6ZTogMTIwcHg7IGZvbnQtd2VpZ2h0OiA3MDA7XCI+e3BhZ2UuVGl0bGV9PC9oMT5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZHluYW1pY0NvbG9yXCIgc3R5bGU9XCJmb250LXNpemU6IDI1cHg7IGZvbnQtd2VpZ2h0OiA3MDA7XCI+e3BhZ2UuRGF0ZX08L2gzPlxyXG4gIDwvZGl2PlxyXG4gICAge3BhZ2UuQ29udGVudH1cclxuICAgIDxzdHlsZSBqc3g+e2BcclxuICAgICAgIC5wb3N0SGVhZGVycyB7XHJcbiAgICAgICAgbGVmdDogODBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMjUlO1xyXG4gICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogLTM4MHB4O1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgfVxyXG4gICAgLnBhZ2VIZWFkZXIge1xyXG4gICAgICAgIHdpZHRoOiBjYWxjKDEwMCUgLSA2MHB4KTtcclxuICAgICAgICBwYWRkaW5nLXJpZ2h0OiA2MHB4O1xyXG4gICAgICAgIGhlaWdodDogNTAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5wb3N0SW1hZ2Uge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgYH08L3N0eWxlPlxyXG4gIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaGFuZGxlcihyZXEsIHJlcykge1xyXG4gIGNvbnN0IGZldGNoZXIgPSB1cmwgPT4gZmV0Y2godXJsKS50aGVuKHIgPT4gci5qc29uKCkpO1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IHVzZVNXUignL2FwaS9ibG9nRGF0YScsIGZldGNoZXIpO1xyXG5cclxuICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2PmZhaWxlZCB0byBsb2FkPC9kaXY+XHJcbiAgaWYgKCFkYXRhKSByZXR1cm4gPGRpdj5sb2FkaW5nLi4uPC9kaXY+XHJcblxyXG4gIGNvbnN0IHsgcGlkIH0gPSByb3V0ZXIucXVlcnk7XHJcbiAgbGV0IHBhZ2UgPSBkYXRhLkJsb2dEb2N1bWVudC5QYWdlcy5maW5kKHAgPT4gcC5UaXRsZSA9PT0gcGlkKTtcclxuICBpZiAoIXBhZ2UpIHBhZ2UgPSBkYXRhLkJsb2dEb2N1bWVudC5Qb3N0cy5maW5kKHAgPT4gcC5UaXRsZSA9PT0gcGlkKTtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfT5cclxuICAgICAgICB7Z2VuZXJhdGVQYWdlKGRhdGEsIG1haW4ocGFnZSkpfVxyXG4gICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfSJdLCJzb3VyY2VSb290IjoiIn0=