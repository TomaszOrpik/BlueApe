webpackHotUpdate_N_E("pages/[pid]",{

/***/ "./pages/[pid].js":
/*!************************!*\
  !*** ./pages/[pid].js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return handler; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swr */ "./node_modules/swr/esm/index.js");
/* harmony import */ var _Layout_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Layout/layout */ "./Layout/layout.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! unfetch */ "./node_modules/next/dist/build/polyfills/fetch/index.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\Users\\sycho\\Desktop\\Nowy folder\\blogtemplate\\pages\\[pid].js",
    _s = $RefreshSig$();








var main = function main(page, primaryColor) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["3772221868", [primaryColor]]]),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
      src: page.ImageUrl,
      className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["3772221868", [primaryColor]]]) + " " + "postImage"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 5
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["3772221868", [primaryColor]]]) + " " + "container",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["3772221868", [primaryColor]]]) + " " + "postHeaders",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["3772221868", [primaryColor]]]) + " " + "postHead",
          children: page.Categories.join(', ')
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 9
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
          className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["3772221868", [primaryColor]]]) + " " + "dynamicColor",
          children: page.Title
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 9
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
          className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["3772221868", [primaryColor]]]) + " " + "dynamicColor",
          children: page.Date
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 5
      }, this), page.Content]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 3
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
      id: "3772221868",
      dynamic: [primaryColor],
      children: ".postHeaders.__jsx-style-dynamic-selector{left:80px;margin-left:25%;width:50%;z-index:10;}.postHead.__jsx-style-dynamic-selector{font-size:35px;font-weight:700;color:".concat(primaryColor, ";}.dynamicColor.__jsx-style-dynamic-selector{font-size:25px;font-weight:700;}.pageHeader.__jsx-style-dynamic-selector{width:calc(100% - 60px);padding-right:60px;height:50%;}.postImage.__jsx-style-dynamic-selector{width:100%;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcc3ljaG9cXERlc2t0b3BcXE5vd3kgZm9sZGVyXFxibG9ndGVtcGxhdGVcXHBhZ2VzXFxbcGlkXS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFrQmdCLEFBR21CLEFBTUcsQUFLQSxBQUlXLEFBTWIsVUFwQkssQ0FxQnBCLElBZmtCLEFBS0EsU0FJSyxFQWRULEtBTXVCLEFBS3JDLEtBVmUsT0FjQSxJQWJmLE9BY0EsWUFUQSIsImZpbGUiOiJDOlxcVXNlcnNcXHN5Y2hvXFxEZXNrdG9wXFxOb3d5IGZvbGRlclxcYmxvZ3RlbXBsYXRlXFxwYWdlc1xcW3BpZF0uanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdXNlU1dSIGZyb20gJ3N3cidcclxuaW1wb3J0IGdlbmVyYXRlUGFnZSBmcm9tICcuLi9MYXlvdXQvbGF5b3V0J1xyXG5pbXBvcnQgZmV0Y2ggZnJvbSAndW5mZXRjaCdcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL0hvbWUubW9kdWxlLmNzcydcclxuXHJcbmNvbnN0IG1haW4gPSBmdW5jdGlvbihwYWdlLCBwcmltYXJ5Q29sb3IpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgIDxpbWcgY2xhc3NOYW1lPVwicG9zdEltYWdlXCIgc3JjPXtwYWdlLkltYWdlVXJsfSAvPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3RIZWFkZXJzXCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInBvc3RIZWFkXCI+e3BhZ2UuQ2F0ZWdvcmllcy5qb2luKCcsICcpfTwvaDM+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cImR5bmFtaWNDb2xvclwiPntwYWdlLlRpdGxlfTwvaDE+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cImR5bmFtaWNDb2xvclwiPntwYWdlLkRhdGV9PC9oMz5cclxuICAgIDwvZGl2PlxyXG4gICAge3BhZ2UuQ29udGVudH1cclxuICA8L2Rpdj5cclxuICAgIDxzdHlsZSBqc3g+e2BcclxuICAgICAgIC5wb3N0SGVhZGVycyB7XHJcbiAgICAgICAgbGVmdDogODBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMjUlO1xyXG4gICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgei1pbmRleDogMTA7XHJcbiAgICB9XHJcbiAgICAucG9zdEhlYWQge1xyXG4gICAgICBmb250LXNpemU6IDM1cHg7IFxyXG4gICAgICBmb250LXdlaWdodDogNzAwOyBcclxuICAgICAgY29sb3I6ICR7cHJpbWFyeUNvbG9yfTtcclxuICAgIH1cclxuICAgIC5keW5hbWljQ29sb3Ige1xyXG4gICAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgICAucGFnZUhlYWRlciB7XHJcbiAgICAgICAgd2lkdGg6IGNhbGMoMTAwJSAtIDYwcHgpO1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDYwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA1MCU7XHJcbiAgICB9XHJcblxyXG4gICAgLnBvc3RJbWFnZSB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbiAgICBgfTwvc3R5bGU+XHJcbiAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgY29uc3QgZmV0Y2hlciA9IHVybCA9PiBmZXRjaCh1cmwpLnRoZW4ociA9PiByLmpzb24oKSk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gdXNlU1dSKCcvYXBpL2Jsb2dEYXRhJywgZmV0Y2hlcik7XHJcblxyXG4gIGlmIChlcnJvcikgcmV0dXJuIDxkaXY+ZmFpbGVkIHRvIGxvYWQ8L2Rpdj5cclxuICBpZiAoIWRhdGEpIHJldHVybiA8ZGl2PmxvYWRpbmcuLi48L2Rpdj5cclxuXHJcbiAgY29uc3QgeyBwaWQgfSA9IHJvdXRlci5xdWVyeTtcclxuICBsZXQgcGFnZSA9IGRhdGEuQmxvZ0RvY3VtZW50LlBhZ2VzLmZpbmQocCA9PiBwLlRpdGxlID09PSBwaWQpO1xyXG4gIGlmICghcGFnZSkgcGFnZSA9IGRhdGEuQmxvZ0RvY3VtZW50LlBvc3RzLmZpbmQocCA9PiBwLlRpdGxlID09PSBwaWQpO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxyXG4gICAgICAgIHtnZW5lcmF0ZVBhZ2UoZGF0YSwgbWFpbihwYWdlLCBkYXRhLkJsb2dEb2N1bWVudC5CbG9nRGV0YWlscy5QcmltYXJ5Q29sb3IpKX1cclxuICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH0iXX0= */\n/*@ sourceURL=C:\\\\Users\\\\sycho\\\\Desktop\\\\Nowy folder\\\\blogtemplate\\\\pages\\\\[pid].js */")
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, this);
};

function handler(req, res) {
  _s();

  var fetcher = function fetcher(url) {
    return unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url).then(function (r) {
      return r.json();
    });
  };

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"])();

  var _useSWR = Object(swr__WEBPACK_IMPORTED_MODULE_2__["default"])('/api/blogData', fetcher),
      data = _useSWR.data,
      error = _useSWR.error;

  if (error) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "failed to load"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 54,
    columnNumber: 21
  }, this);
  if (!data) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "loading..."
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 55,
    columnNumber: 21
  }, this);
  var pid = router.query.pid;
  var page = data.BlogDocument.Pages.find(function (p) {
    return p.Title === pid;
  });
  if (!page) page = data.BlogDocument.Posts.find(function (p) {
    return p.Title === pid;
  });
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default.a.container,
    children: Object(_Layout_layout__WEBPACK_IMPORTED_MODULE_3__["default"])(data, main(page, data.BlogDocument.BlogDetails.PrimaryColor))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 61,
    columnNumber: 7
  }, this);
}

_s(handler, "F2OQGCTB9lgwThKfzWI7sczFgbA=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"], swr__WEBPACK_IMPORTED_MODULE_2__["default"]];
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvW3BpZF0uanMiXSwibmFtZXMiOlsibWFpbiIsInBhZ2UiLCJwcmltYXJ5Q29sb3IiLCJJbWFnZVVybCIsIkNhdGVnb3JpZXMiLCJqb2luIiwiVGl0bGUiLCJEYXRlIiwiQ29udGVudCIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJmZXRjaGVyIiwidXJsIiwiZmV0Y2giLCJ0aGVuIiwiciIsImpzb24iLCJyb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJ1c2VTV1IiLCJkYXRhIiwiZXJyb3IiLCJwaWQiLCJxdWVyeSIsIkJsb2dEb2N1bWVudCIsIlBhZ2VzIiwiZmluZCIsInAiLCJQb3N0cyIsInN0eWxlcyIsImNvbnRhaW5lciIsImdlbmVyYXRlUGFnZSIsIkJsb2dEZXRhaWxzIiwiUHJpbWFyeUNvbG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQU1BLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQVNDLElBQVQsRUFBZUMsWUFBZixFQUE2QjtBQUN4QyxzQkFDRTtBQUFBLGdHQW9CV0EsWUFwQlg7QUFBQSw0QkFDQTtBQUEyQixTQUFHLEVBQUVELElBQUksQ0FBQ0UsUUFBckM7QUFBQSxrR0FtQldELFlBbkJYLGFBQWU7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREEsZUFFRjtBQUFBLGtHQWtCYUEsWUFsQmIsYUFBZSxXQUFmO0FBQUEsOEJBQ0U7QUFBQSxvR0FpQldBLFlBakJYLGFBQWUsYUFBZjtBQUFBLGdDQUNJO0FBQUEsc0dBZ0JPQSxZQWhCUCxhQUFjLFVBQWQ7QUFBQSxvQkFBMEJELElBQUksQ0FBQ0csVUFBTCxDQUFnQkMsSUFBaEIsQ0FBcUIsSUFBckI7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixlQUVJO0FBQUEsc0dBZU9ILFlBZlAsYUFBYyxjQUFkO0FBQUEsb0JBQThCRCxJQUFJLENBQUNLO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkosZUFHSTtBQUFBLHNHQWNPSixZQWRQLGFBQWMsY0FBZDtBQUFBLG9CQUE4QkQsSUFBSSxDQUFDTTtBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLEVBTUdOLElBQUksQ0FBQ08sT0FOUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRTtBQUFBO0FBQUEsZ0JBb0JXTixZQXBCWDtBQUFBLGdNQW9CV0EsWUFwQlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXVDRCxDQXhDRDs7QUEwQ2UsU0FBU08sT0FBVCxDQUFpQkMsR0FBakIsRUFBc0JDLEdBQXRCLEVBQTJCO0FBQUE7O0FBQ3hDLE1BQU1DLE9BQU8sR0FBRyxTQUFWQSxPQUFVLENBQUFDLEdBQUc7QUFBQSxXQUFJQyw4Q0FBSyxDQUFDRCxHQUFELENBQUwsQ0FBV0UsSUFBWCxDQUFnQixVQUFBQyxDQUFDO0FBQUEsYUFBSUEsQ0FBQyxDQUFDQyxJQUFGLEVBQUo7QUFBQSxLQUFqQixDQUFKO0FBQUEsR0FBbkI7O0FBQ0EsTUFBTUMsTUFBTSxHQUFHQyw2REFBUyxFQUF4Qjs7QUFGd0MsZ0JBR2hCQyxtREFBTSxDQUFDLGVBQUQsRUFBa0JSLE9BQWxCLENBSFU7QUFBQSxNQUdoQ1MsSUFIZ0MsV0FHaENBLElBSGdDO0FBQUEsTUFHMUJDLEtBSDBCLFdBRzFCQSxLQUgwQjs7QUFLeEMsTUFBSUEsS0FBSixFQUFXLG9CQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDWCxNQUFJLENBQUNELElBQUwsRUFBVyxvQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBTjZCLE1BUWhDRSxHQVJnQyxHQVF4QkwsTUFBTSxDQUFDTSxLQVJpQixDQVFoQ0QsR0FSZ0M7QUFTeEMsTUFBSXRCLElBQUksR0FBR29CLElBQUksQ0FBQ0ksWUFBTCxDQUFrQkMsS0FBbEIsQ0FBd0JDLElBQXhCLENBQTZCLFVBQUFDLENBQUM7QUFBQSxXQUFJQSxDQUFDLENBQUN0QixLQUFGLEtBQVlpQixHQUFoQjtBQUFBLEdBQTlCLENBQVg7QUFDQSxNQUFJLENBQUN0QixJQUFMLEVBQVdBLElBQUksR0FBR29CLElBQUksQ0FBQ0ksWUFBTCxDQUFrQkksS0FBbEIsQ0FBd0JGLElBQXhCLENBQTZCLFVBQUFDLENBQUM7QUFBQSxXQUFJQSxDQUFDLENBQUN0QixLQUFGLEtBQVlpQixHQUFoQjtBQUFBLEdBQTlCLENBQVA7QUFDVCxzQkFDRTtBQUFLLGFBQVMsRUFBRU8sOERBQU0sQ0FBQ0MsU0FBdkI7QUFBQSxjQUNHQyw4REFBWSxDQUFDWCxJQUFELEVBQU9yQixJQUFJLENBQUNDLElBQUQsRUFBT29CLElBQUksQ0FBQ0ksWUFBTCxDQUFrQlEsV0FBbEIsQ0FBOEJDLFlBQXJDLENBQVg7QUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFLRDs7R0FoQnFCekIsTztVQUVQVSxxRCxFQUNTQywyQyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9bcGlkXS5mZGVkZjZiMWJiOTQzZjE5NzIzYS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHVzZVNXUiBmcm9tICdzd3InXHJcbmltcG9ydCBnZW5lcmF0ZVBhZ2UgZnJvbSAnLi4vTGF5b3V0L2xheW91dCdcclxuaW1wb3J0IGZldGNoIGZyb20gJ3VuZmV0Y2gnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXHJcblxyXG5jb25zdCBtYWluID0gZnVuY3Rpb24ocGFnZSwgcHJpbWFyeUNvbG9yKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICA8aW1nIGNsYXNzTmFtZT1cInBvc3RJbWFnZVwiIHNyYz17cGFnZS5JbWFnZVVybH0gLz5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwb3N0SGVhZGVyc1wiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJwb3N0SGVhZFwiPntwYWdlLkNhdGVnb3JpZXMuam9pbignLCAnKX08L2gzPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJkeW5hbWljQ29sb3JcIj57cGFnZS5UaXRsZX08L2gxPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJkeW5hbWljQ29sb3JcIj57cGFnZS5EYXRlfTwvaDM+XHJcbiAgICA8L2Rpdj5cclxuICAgIHtwYWdlLkNvbnRlbnR9XHJcbiAgPC9kaXY+XHJcbiAgICA8c3R5bGUganN4PntgXHJcbiAgICAgICAucG9zdEhlYWRlcnMge1xyXG4gICAgICAgIGxlZnQ6IDgwcHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDI1JTtcclxuICAgICAgICB3aWR0aDogNTAlO1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgfVxyXG4gICAgLnBvc3RIZWFkIHtcclxuICAgICAgZm9udC1zaXplOiAzNXB4OyBcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDsgXHJcbiAgICAgIGNvbG9yOiAke3ByaW1hcnlDb2xvcn07XHJcbiAgICB9XHJcbiAgICAuZHluYW1pY0NvbG9yIHtcclxuICAgICAgZm9udC1zaXplOiAyNXB4O1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgfVxyXG4gICAgLnBhZ2VIZWFkZXIge1xyXG4gICAgICAgIHdpZHRoOiBjYWxjKDEwMCUgLSA2MHB4KTtcclxuICAgICAgICBwYWRkaW5nLXJpZ2h0OiA2MHB4O1xyXG4gICAgICAgIGhlaWdodDogNTAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5wb3N0SW1hZ2Uge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgYH08L3N0eWxlPlxyXG4gIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaGFuZGxlcihyZXEsIHJlcykge1xyXG4gIGNvbnN0IGZldGNoZXIgPSB1cmwgPT4gZmV0Y2godXJsKS50aGVuKHIgPT4gci5qc29uKCkpO1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IHVzZVNXUignL2FwaS9ibG9nRGF0YScsIGZldGNoZXIpO1xyXG5cclxuICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2PmZhaWxlZCB0byBsb2FkPC9kaXY+XHJcbiAgaWYgKCFkYXRhKSByZXR1cm4gPGRpdj5sb2FkaW5nLi4uPC9kaXY+XHJcblxyXG4gIGNvbnN0IHsgcGlkIH0gPSByb3V0ZXIucXVlcnk7XHJcbiAgbGV0IHBhZ2UgPSBkYXRhLkJsb2dEb2N1bWVudC5QYWdlcy5maW5kKHAgPT4gcC5UaXRsZSA9PT0gcGlkKTtcclxuICBpZiAoIXBhZ2UpIHBhZ2UgPSBkYXRhLkJsb2dEb2N1bWVudC5Qb3N0cy5maW5kKHAgPT4gcC5UaXRsZSA9PT0gcGlkKTtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfT5cclxuICAgICAgICB7Z2VuZXJhdGVQYWdlKGRhdGEsIG1haW4ocGFnZSwgZGF0YS5CbG9nRG9jdW1lbnQuQmxvZ0RldGFpbHMuUHJpbWFyeUNvbG9yKSl9XHJcbiAgICA8L2Rpdj5cclxuICAgIClcclxuICB9Il0sInNvdXJjZVJvb3QiOiIifQ==