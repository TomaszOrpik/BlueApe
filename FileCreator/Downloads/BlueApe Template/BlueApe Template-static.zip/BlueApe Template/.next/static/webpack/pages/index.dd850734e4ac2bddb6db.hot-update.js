webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swr */ "./node_modules/swr/esm/index.js");
/* harmony import */ var _Layout_layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Layout/layout */ "./Layout/layout.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! unfetch */ "./node_modules/next/dist/build/polyfills/fetch/index.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(unfetch__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "C:\\Users\\sycho\\Desktop\\Nowy folder\\blogtemplate\\pages\\index.js",
    _s = $RefreshSig$();









var main = function main(posts, primaryColor) {
  var _this = this;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("main", {
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]) + " " + "main",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_7___default.a, {
      href: "/" + posts[0].Title,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
        className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
          src: posts[0].ImageUrl,
          className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]])
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, this), posts.slice(1).map(function (post) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]) + " " + "bodySquare",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]) + " " + "squareBase normalCursor row",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]) + " " + "left col-6",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_7___default.a, {
              href: "/" + post.Title,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]),
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]) + " " + "imageContainer",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                    src: post.ImageUrl,
                    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]])
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 23
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 25,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 24,
                columnNumber: 19
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 23,
              columnNumber: 17
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 15
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]) + " " + "right col-6",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_7___default.a, {
              href: "/" + post.Title,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]) + " " + "blackFont",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
                  className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]),
                  children: post.Title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 44
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 19
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 17
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]),
              children: post.Intro
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 35,
              columnNumber: 17
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
              className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a.dynamic([["921512363", [primaryColor]]]),
              children: post.Date
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 17
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 15
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 13
        }, _this)
      }, Math.random(), false, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 11
      }, _this);
    }), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
      id: "921512363",
      dynamic: [primaryColor],
      children: "h1.__jsx-style-dynamic-selector{font-size:40px;}span.__jsx-style-dynamic-selector{font-size:26px;}h3.__jsx-style-dynamic-selector{font-size:25px;}.containerBody.__jsx-style-dynamic-selector{width:100%;}.bodySquare.__jsx-style-dynamic-selector{width:75%;height:300px;margin-top:5%;}.squareBase.__jsx-style-dynamic-selector{width:125%;height:250px;}.normalCursor.__jsx-style-dynamic-selector{cursor:default !important;}.blackFont.__jsx-style-dynamic-selector{color:black;font-weight:700;}.blackFont.__jsx-style-dynamic-selector:hover{color:".concat(primaryColor, ";}.imageContainer.__jsx-style-dynamic-selector{width:100%;}.imageContainer.__jsx-style-dynamic-selector>img.__jsx-style-dynamic-selector{width:100%;height:auto;}.main.__jsx-style-dynamic-selector{padding:5rem 0;-webkit-flex:1;-ms-flex:1;flex:1;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcc3ljaG9cXERlc2t0b3BcXE5vd3kgZm9sZGVyXFxibG9ndGVtcGxhdGVcXHBhZ2VzXFxpbmRleC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUEwQ2tCLEFBRzRCLEFBR0EsQUFHQSxBQUdKLEFBSUQsQUFNQyxBQUllLEFBR2QsQUFJcUIsQUFJMUIsQUFHQSxBQU1JLFVBN0JFLENBSmpCLEFBVWlCLEFBZW5CLEFBR2MsQ0FYUSxHQTFCcEIsQUFHQSxBQUdBLEFBcUNPLFFBN0JXLEFBd0JwQixDQWxCRSxFQUdBLEVBSUEsT0FHQSxFQWZBLFdBNkJhLDBFQUNTLDhFQUNDLG1HQUNKLDZGQUNyQiIsImZpbGUiOiJDOlxcVXNlcnNcXHN5Y2hvXFxEZXNrdG9wXFxOb3d5IGZvbGRlclxcYmxvZ3RlbXBsYXRlXFxwYWdlc1xcaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXG5pbXBvcnQgdXNlU1dSIGZyb20gJ3N3cidcbmltcG9ydCBnZW5lcmF0ZVBhZ2UgZnJvbSAnLi4vTGF5b3V0L2xheW91dCdcbmltcG9ydCBmZXRjaCBmcm9tICd1bmZldGNoJ1xuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xuXG5cbmNvbnN0IG1haW4gPSBmdW5jdGlvbiAocG9zdHMsIHByaW1hcnlDb2xvcikge1xuICByZXR1cm4gKFxuICAgIDxtYWluIGNsYXNzTmFtZT1cIm1haW5cIj5cbiAgICAgIDxMaW5rIGhyZWY9e1wiL1wiICsgcG9zdHNbMF0uVGl0bGV9PlxuICAgICAgICA8YT5cbiAgICAgICAgICA8aW1nIHNyYz17cG9zdHNbMF0uSW1hZ2VVcmx9IC8+XG4gICAgICAgIDwvYT5cbiAgICAgIDwvTGluaz5cbiAgICAgIHtcbiAgICAgICAgcG9zdHMuc2xpY2UoMSkubWFwKHBvc3QgPT5cbiAgICAgICAgKFxuICAgICAgICAgIDxkaXYga2V5PXtNYXRoLnJhbmRvbSgpfSBjbGFzc05hbWU9XCJib2R5U3F1YXJlXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNxdWFyZUJhc2Ugbm9ybWFsQ3Vyc29yIHJvd1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxlZnQgY29sLTZcIj5cbiAgICAgICAgICAgICAgICA8TGluayBocmVmPXtcIi9cIiArIHBvc3QuVGl0bGV9PlxuICAgICAgICAgICAgICAgICAgPGE+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW1hZ2VDb250YWluZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17cG9zdC5JbWFnZVVybH0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaWdodCBjb2wtNlwiPlxuICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e1wiL1wiICsgcG9zdC5UaXRsZX0+XG4gICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJibGFja0ZvbnRcIj48aDE+e3Bvc3QuVGl0bGV9PC9oMT48L2E+XG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDxzcGFuPntwb3N0LkludHJvfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aDM+e3Bvc3QuRGF0ZX08L2gzPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PilcblxuICAgICAgICApXG4gICAgICB9XG4gICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgaDEge1xuICAgICAgICAgICAgZm9udC1zaXplOiA0MHB4O1xuICAgICAgICB9XG4gICAgICAgIHNwYW4ge1xuICAgICAgICAgICAgZm9udC1zaXplOiAyNnB4O1xuICAgICAgICB9XG4gICAgICAgIGgzIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjVweDtcbiAgICAgICAgfVxuICAgICAgICAuY29udGFpbmVyQm9keSB7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgfVxuICAgIFxuICAgICAgICAuYm9keVNxdWFyZSB7XG4gICAgICAgICAgICB3aWR0aDogNzUlO1xuICAgICAgICAgICAgaGVpZ2h0OiAzMDBweDtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDUlO1xuICAgICAgICB9XG4gICAgXG4gICAgICAgIC5zcXVhcmVCYXNlIHtcbiAgICAgICAgICAgIHdpZHRoOiAxMjUlO1xuICAgICAgICAgICAgaGVpZ2h0OiAyNTBweDtcbiAgICAgICAgfVxuICAgICAgICAubm9ybWFsQ3Vyc29yIHtcbiAgICAgICAgICAgIGN1cnNvcjogZGVmYXVsdCAhaW1wb3J0YW50O1xuICAgICAgICB9XG4gICAgICAgIC5ibGFja0ZvbnQge1xuICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICAgICAgfVxuICAgICAgICAuYmxhY2tGb250OmhvdmVyIHtcbiAgICAgICAgICBjb2xvcjogJHtwcmltYXJ5Q29sb3J9O1xuICAgICAgICB9XG5cbiAgICAgIC5pbWFnZUNvbnRhaW5lciB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgfVxuICAgICAgLmltYWdlQ29udGFpbmVyID4gaW1nIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogYXV0bztcbiAgICAgIH1cblxuICAgICAgXG4gICAgICAubWFpbiB7XG4gICAgICAgIHBhZGRpbmc6IDVyZW0gMDtcbiAgICAgICAgZmxleDogMTtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICB9YH08L3N0eWxlPlxuICAgIDwvbWFpbj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgZmV0Y2hlciA9IHVybCA9PiBmZXRjaCh1cmwpLnRoZW4ociA9PiByLmpzb24oKSk7XG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IHVzZVNXUignL2FwaS9ibG9nRGF0YScsIGZldGNoZXIpO1xuXG4gIGlmIChlcnJvcikgcmV0dXJuIDxkaXY+ZmFpbGVkIHRvIGxvYWQ8L2Rpdj5cbiAgaWYgKCFkYXRhKSByZXR1cm4gPGRpdj5sb2FkaW5nLi4uPC9kaXY+XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPkNyZWF0ZSBOZXh0IEFwcDwvdGl0bGU+XG4gICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgIDwvSGVhZD5cbiAgICAgIDxib2R5PlxuICAgICAgICB7Z2VuZXJhdGVQYWdlKGRhdGEsIG1haW4oZGF0YS5CbG9nRG9jdW1lbnQuUG9zdHMsIGRhdGEuQmxvZ0RvY3VtZW50LkJsb2dEZXRhaWxzLlByaW1hcnlDb2xvcikpfVxuICAgICAgPC9ib2R5PlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0= */\n/*@ sourceURL=C:\\\\Users\\\\sycho\\\\Desktop\\\\Nowy folder\\\\blogtemplate\\\\pages\\\\index.js */")
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 5
  }, this);
};

function Home() {
  _s();

  var fetcher = function fetcher(url) {
    return unfetch__WEBPACK_IMPORTED_MODULE_6___default()(url).then(function (r) {
      return r.json();
    });
  };

  var _useSWR = Object(swr__WEBPACK_IMPORTED_MODULE_4__["default"])('/api/blogData', fetcher),
      data = _useSWR.data,
      error = _useSWR.error;

  if (error) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "failed to load"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 103,
    columnNumber: 21
  }, this);
  if (!data) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "loading..."
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 104,
    columnNumber: 21
  }, this);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3___default.a.container,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 109,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 110,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 108,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("body", {
      children: Object(_Layout_layout__WEBPACK_IMPORTED_MODULE_5__["default"])(data, main(data.BlogDocument.Posts, data.BlogDocument.BlogDetails.PrimaryColor))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 107,
    columnNumber: 5
  }, this);
}

_s(Home, "r2QYs02BSrn+Eu/1uMGZi8N+HnQ=", false, function () {
  return [swr__WEBPACK_IMPORTED_MODULE_4__["default"]];
});

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsibWFpbiIsInBvc3RzIiwicHJpbWFyeUNvbG9yIiwiVGl0bGUiLCJJbWFnZVVybCIsInNsaWNlIiwibWFwIiwicG9zdCIsIkludHJvIiwiRGF0ZSIsIk1hdGgiLCJyYW5kb20iLCJIb21lIiwiZmV0Y2hlciIsInVybCIsImZldGNoIiwidGhlbiIsInIiLCJqc29uIiwidXNlU1dSIiwiZGF0YSIsImVycm9yIiwic3R5bGVzIiwiY29udGFpbmVyIiwiZ2VuZXJhdGVQYWdlIiwiQmxvZ0RvY3VtZW50IiwiUG9zdHMiLCJCbG9nRGV0YWlscyIsIlByaW1hcnlDb2xvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0EsSUFBTUEsSUFBSSxHQUFHLFNBQVBBLElBQU8sQ0FBVUMsS0FBVixFQUFpQkMsWUFBakIsRUFBK0I7QUFBQTs7QUFDMUMsc0JBQ0U7QUFBQSwrRkFnRWVBLFlBaEVmLGFBQWdCLE1BQWhCO0FBQUEsNEJBQ0UscUVBQUMsZ0RBQUQ7QUFBTSxVQUFJLEVBQUUsTUFBTUQsS0FBSyxDQUFDLENBQUQsQ0FBTCxDQUFTRSxLQUEzQjtBQUFBLDZCQUNFO0FBQUEsbUdBOERXRCxZQTlEWDtBQUFBLCtCQUNFO0FBQUssYUFBRyxFQUFFRCxLQUFLLENBQUMsQ0FBRCxDQUFMLENBQVNHLFFBQW5CO0FBQUEscUdBNkRTRixZQTdEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLEVBT0lELEtBQUssQ0FBQ0ksS0FBTixDQUFZLENBQVosRUFBZUMsR0FBZixDQUFtQixVQUFBQyxJQUFJO0FBQUEsMEJBRXJCO0FBQUEsbUdBdURTTCxZQXZEVCxhQUFtQyxZQUFuQztBQUFBLCtCQUNFO0FBQUEscUdBc0RPQSxZQXREUCxhQUFlLDZCQUFmO0FBQUEsa0NBQ0U7QUFBQSx1R0FxREtBLFlBckRMLGFBQWUsWUFBZjtBQUFBLG1DQUNFLHFFQUFDLGdEQUFEO0FBQU0sa0JBQUksRUFBRSxNQUFNSyxJQUFJLENBQUNKLEtBQXZCO0FBQUEscUNBQ0U7QUFBQSwyR0FtRENELFlBbkREO0FBQUEsdUNBQ0U7QUFBQSw2R0FrRERBLFlBbERDLGFBQWUsZ0JBQWY7QUFBQSx5Q0FDRTtBQUFLLHVCQUFHLEVBQUVLLElBQUksQ0FBQ0gsUUFBZjtBQUFBLCtHQWlESEYsWUFqREc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVVFO0FBQUEsdUdBNENLQSxZQTVDTCxhQUFlLGFBQWY7QUFBQSxvQ0FDRSxxRUFBQyxnREFBRDtBQUFNLGtCQUFJLEVBQUUsTUFBTUssSUFBSSxDQUFDSixLQUF2QjtBQUFBLHFDQUNFO0FBQUEsMkdBMENDRCxZQTFDRCxhQUFhLFdBQWI7QUFBQSx1Q0FBeUI7QUFBQSw2R0EwQ3hCQSxZQTFDd0I7QUFBQSw0QkFBS0ssSUFBSSxDQUFDSjtBQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFJRTtBQUFBLHlHQXdDR0QsWUF4Q0g7QUFBQSx3QkFBT0ssSUFBSSxDQUFDQztBQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkYsZUFLRTtBQUFBLHlHQXVDR04sWUF2Q0g7QUFBQSx3QkFBS0ssSUFBSSxDQUFDRTtBQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQVVDLElBQUksQ0FBQ0MsTUFBTCxFQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGcUI7QUFBQSxLQUF2QixDQVBKO0FBQUE7QUFBQSxnQkFnRWVULFlBaEVmO0FBQUEsb2pCQWdFZUEsWUFoRWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXVGRCxDQXhGRDs7QUEwRmUsU0FBU1UsSUFBVCxHQUFnQjtBQUFBOztBQUM3QixNQUFNQyxPQUFPLEdBQUcsU0FBVkEsT0FBVSxDQUFBQyxHQUFHO0FBQUEsV0FBSUMsOENBQUssQ0FBQ0QsR0FBRCxDQUFMLENBQVdFLElBQVgsQ0FBZ0IsVUFBQUMsQ0FBQztBQUFBLGFBQUlBLENBQUMsQ0FBQ0MsSUFBRixFQUFKO0FBQUEsS0FBakIsQ0FBSjtBQUFBLEdBQW5COztBQUQ2QixnQkFFTEMsbURBQU0sQ0FBQyxlQUFELEVBQWtCTixPQUFsQixDQUZEO0FBQUEsTUFFckJPLElBRnFCLFdBRXJCQSxJQUZxQjtBQUFBLE1BRWZDLEtBRmUsV0FFZkEsS0FGZTs7QUFJN0IsTUFBSUEsS0FBSixFQUFXLG9CQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDWCxNQUFJLENBQUNELElBQUwsRUFBVyxvQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBRVgsc0JBQ0U7QUFBSyxhQUFTLEVBQUVFLDhEQUFNLENBQUNDLFNBQXZCO0FBQUEsNEJBQ0UscUVBQUMsZ0RBQUQ7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUU7QUFBTSxXQUFHLEVBQUMsTUFBVjtBQUFpQixZQUFJLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBS0U7QUFBQSxnQkFDR0MsOERBQVksQ0FBQ0osSUFBRCxFQUFPcEIsSUFBSSxDQUFDb0IsSUFBSSxDQUFDSyxZQUFMLENBQWtCQyxLQUFuQixFQUEwQk4sSUFBSSxDQUFDSyxZQUFMLENBQWtCRSxXQUFsQixDQUE4QkMsWUFBeEQsQ0FBWDtBQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVdEOztHQWxCdUJoQixJO1VBRUVPLDJDOzs7S0FGRlAsSSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5kZDg1MDczNGU0YWMyYmRkYjZkYi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xuaW1wb3J0IHVzZVNXUiBmcm9tICdzd3InXG5pbXBvcnQgZ2VuZXJhdGVQYWdlIGZyb20gJy4uL0xheW91dC9sYXlvdXQnXG5pbXBvcnQgZmV0Y2ggZnJvbSAndW5mZXRjaCdcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcblxuXG5jb25zdCBtYWluID0gZnVuY3Rpb24gKHBvc3RzLCBwcmltYXJ5Q29sb3IpIHtcbiAgcmV0dXJuIChcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJtYWluXCI+XG4gICAgICA8TGluayBocmVmPXtcIi9cIiArIHBvc3RzWzBdLlRpdGxlfT5cbiAgICAgICAgPGE+XG4gICAgICAgICAgPGltZyBzcmM9e3Bvc3RzWzBdLkltYWdlVXJsfSAvPlxuICAgICAgICA8L2E+XG4gICAgICA8L0xpbms+XG4gICAgICB7XG4gICAgICAgIHBvc3RzLnNsaWNlKDEpLm1hcChwb3N0ID0+XG4gICAgICAgIChcbiAgICAgICAgICA8ZGl2IGtleT17TWF0aC5yYW5kb20oKX0gY2xhc3NOYW1lPVwiYm9keVNxdWFyZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcXVhcmVCYXNlIG5vcm1hbEN1cnNvciByb3dcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWZ0IGNvbC02XCI+XG4gICAgICAgICAgICAgICAgPExpbmsgaHJlZj17XCIvXCIgKyBwb3N0LlRpdGxlfT5cbiAgICAgICAgICAgICAgICAgIDxhPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImltYWdlQ29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e3Bvc3QuSW1hZ2VVcmx9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmlnaHQgY29sLTZcIj5cbiAgICAgICAgICAgICAgICA8TGluayBocmVmPXtcIi9cIiArIHBvc3QuVGl0bGV9PlxuICAgICAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwiYmxhY2tGb250XCI+PGgxPntwb3N0LlRpdGxlfTwvaDE+PC9hPlxuICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICA8c3Bhbj57cG9zdC5JbnRyb308L3NwYW4+XG4gICAgICAgICAgICAgICAgPGgzPntwb3N0LkRhdGV9PC9oMz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj4pXG5cbiAgICAgICAgKVxuICAgICAgfVxuICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIGgxIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICAgICAgfVxuICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjZweDtcbiAgICAgICAgfVxuICAgICAgICBoMyB7XG4gICAgICAgICAgICBmb250LXNpemU6IDI1cHg7XG4gICAgICAgIH1cbiAgICAgICAgLmNvbnRhaW5lckJvZHkge1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIH1cbiAgICBcbiAgICAgICAgLmJvZHlTcXVhcmUge1xuICAgICAgICAgICAgd2lkdGg6IDc1JTtcbiAgICAgICAgICAgIGhlaWdodDogMzAwcHg7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiA1JTtcbiAgICAgICAgfVxuICAgIFxuICAgICAgICAuc3F1YXJlQmFzZSB7XG4gICAgICAgICAgICB3aWR0aDogMTI1JTtcbiAgICAgICAgICAgIGhlaWdodDogMjUwcHg7XG4gICAgICAgIH1cbiAgICAgICAgLm5vcm1hbEN1cnNvciB7XG4gICAgICAgICAgICBjdXJzb3I6IGRlZmF1bHQgIWltcG9ydGFudDtcbiAgICAgICAgfVxuICAgICAgICAuYmxhY2tGb250IHtcbiAgICAgICAgICAgIGNvbG9yOiBibGFjaztcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICAgIH1cbiAgICAgICAgLmJsYWNrRm9udDpob3ZlciB7XG4gICAgICAgICAgY29sb3I6ICR7cHJpbWFyeUNvbG9yfTtcbiAgICAgICAgfVxuXG4gICAgICAuaW1hZ2VDb250YWluZXIge1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgIH1cbiAgICAgIC5pbWFnZUNvbnRhaW5lciA+IGltZyB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IGF1dG87XG4gICAgICB9XG5cbiAgICAgIFxuICAgICAgLm1haW4ge1xuICAgICAgICBwYWRkaW5nOiA1cmVtIDA7XG4gICAgICAgIGZsZXg6IDE7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgfWB9PC9zdHlsZT5cbiAgICA8L21haW4+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIGNvbnN0IGZldGNoZXIgPSB1cmwgPT4gZmV0Y2godXJsKS50aGVuKHIgPT4gci5qc29uKCkpO1xuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSB1c2VTV1IoJy9hcGkvYmxvZ0RhdGEnLCBmZXRjaGVyKTtcblxuICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2PmZhaWxlZCB0byBsb2FkPC9kaXY+XG4gIGlmICghZGF0YSkgcmV0dXJuIDxkaXY+bG9hZGluZy4uLjwvZGl2PlxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5DcmVhdGUgTmV4dCBBcHA8L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8Ym9keT5cbiAgICAgICAge2dlbmVyYXRlUGFnZShkYXRhLCBtYWluKGRhdGEuQmxvZ0RvY3VtZW50LlBvc3RzLCBkYXRhLkJsb2dEb2N1bWVudC5CbG9nRGV0YWlscy5QcmltYXJ5Q29sb3IpKX1cbiAgICAgIDwvYm9keT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==