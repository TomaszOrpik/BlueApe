const MongoClient = require('mongodb').MongoClient;

      export default (req, res) => {
        const url = "mongodb://localhost:27017/";
        const dbName = 'BlueApeDB'
        const collectionName = 'BlueApe Template';
        MongoClient.connect(url, function(err, db) {
          if (err) throw err;
          var dbo = db.db(dbName);
          dbo.collection(collectionName).findOne({}, function(err, result) {
            if (err) throw err;
            res.status(200).json(result);
          })
        })
      }