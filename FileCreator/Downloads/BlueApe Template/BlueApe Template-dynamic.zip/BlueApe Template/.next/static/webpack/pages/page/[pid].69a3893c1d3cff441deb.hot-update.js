webpackHotUpdate_N_E("pages/page/[pid]",{

/***/ "./pages/page/[pid].js":
/*!*****************************!*\
  !*** ./pages/page/[pid].js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return handler; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swr */ "./node_modules/swr/esm/index.js");
/* harmony import */ var _Layout_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../Layout/layout */ "./Layout/layout.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! unfetch */ "./node_modules/next/dist/build/polyfills/fetch/index.js");
/* harmony import */ var unfetch__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(unfetch__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\Users\\sycho\\Desktop\\Nowy folder\\blogtemplate\\pages\\page\\[pid].js",
    _s = $RefreshSig$();








var main = function main(page) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "jsx-3733475335",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
      src: page.ImageUrl,
      className: "jsx-3733475335" + " " + "postImage"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 5
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "jsx-3733475335" + " " + "postHeaders",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        style: "font-size: 35px; font-weight: 700; color: @(blogModel.primaryColor)",
        className: "jsx-3733475335",
        children: page.Categories.join(', ')
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
        style: "font-size: 120px; font-weight: 700;",
        className: "jsx-3733475335" + " " + "dynamicColor",
        children: page.Title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        style: "font-size: 25px; font-weight: 700;",
        className: "jsx-3733475335" + " " + "dynamicColor",
        children: "page.Date"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 5
    }, this), page.Content, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
      id: "3733475335",
      children: ".postHeaders.jsx-3733475335{left:80px;margin-left:25%;width:50%;margin-top:-380px;z-index:10;}.pageHeader.jsx-3733475335{width:calc(100% - 60px);padding-right:60px;height:50%;}.postImage.jsx-3733475335{left:60px;width:calc(100% - 60px);position:absolute;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcc3ljaG9cXERlc2t0b3BcXE5vd3kgZm9sZGVyXFxibG9ndGVtcGxhdGVcXHBhZ2VzXFxwYWdlXFxbcGlkXS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFnQmdCLEFBR21CLEFBT2MsQUFNZCxVQVpNLEFBYVEsY0FOTCxFQU5ULFFBYVEsRUFaQSxPQU1QLFNBT2YsRUFaZSxBQU1mLFdBTEEiLCJmaWxlIjoiQzpcXFVzZXJzXFxzeWNob1xcRGVza3RvcFxcTm93eSBmb2xkZXJcXGJsb2d0ZW1wbGF0ZVxccGFnZXNcXHBhZ2VcXFtwaWRdLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHVzZVNXUiBmcm9tICdzd3InXHJcbmltcG9ydCBnZW5lcmF0ZVBhZ2UgZnJvbSAnLi4vLi4vTGF5b3V0L2xheW91dCdcclxuaW1wb3J0IGZldGNoIGZyb20gJ3VuZmV0Y2gnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uLy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXHJcblxyXG5jb25zdCBtYWluID0gZnVuY3Rpb24ocGFnZSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgPGltZyBjbGFzc05hbWU9XCJwb3N0SW1hZ2VcIiBzcmM9e3BhZ2UuSW1hZ2VVcmx9IC8+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3RIZWFkZXJzXCI+XHJcbiAgICAgICAgPGgzIHN0eWxlPVwiZm9udC1zaXplOiAzNXB4OyBmb250LXdlaWdodDogNzAwOyBjb2xvcjogQChibG9nTW9kZWwucHJpbWFyeUNvbG9yKVwiPntwYWdlLkNhdGVnb3JpZXMuam9pbignLCAnKX08L2gzPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJkeW5hbWljQ29sb3JcIiBzdHlsZT1cImZvbnQtc2l6ZTogMTIwcHg7IGZvbnQtd2VpZ2h0OiA3MDA7XCI+e3BhZ2UuVGl0bGV9PC9oMT5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZHluYW1pY0NvbG9yXCIgc3R5bGU9XCJmb250LXNpemU6IDI1cHg7IGZvbnQtd2VpZ2h0OiA3MDA7XCI+cGFnZS5EYXRlPC9oMz5cclxuICAgIDwvZGl2PlxyXG4gICAge3BhZ2UuQ29udGVudH1cclxuICAgIDxzdHlsZSBqc3g+e2BcclxuICAgICAgIC5wb3N0SGVhZGVycyB7XHJcbiAgICAgICAgbGVmdDogODBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMjUlO1xyXG4gICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogLTM4MHB4O1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgfVxyXG4gICAgLnBhZ2VIZWFkZXIge1xyXG4gICAgICAgIHdpZHRoOiBjYWxjKDEwMCUgLSA2MHB4KTtcclxuICAgICAgICBwYWRkaW5nLXJpZ2h0OiA2MHB4O1xyXG4gICAgICAgIGhlaWdodDogNTAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5wb3N0SW1hZ2Uge1xyXG4gICAgICAgIGxlZnQ6IDYwcHg7XHJcbiAgICAgICAgd2lkdGg6IGNhbGMoMTAwJSAtIDYwcHgpO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIH1cclxuICAgIGB9PC9zdHlsZT5cclxuICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICBjb25zdCBmZXRjaGVyID0gdXJsID0+IGZldGNoKHVybCkudGhlbihyID0+IHIuanNvbigpKTtcclxuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSB1c2VTV1IoJy9hcGkvYmxvZ0RhdGEnLCBmZXRjaGVyKTtcclxuXHJcbiAgaWYgKGVycm9yKSByZXR1cm4gPGRpdj5mYWlsZWQgdG8gbG9hZDwvZGl2PlxyXG4gIGlmICghZGF0YSkgcmV0dXJuIDxkaXY+bG9hZGluZy4uLjwvZGl2PlxyXG5cclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG4gIGNvbnN0IHsgcGlkIH0gPSByb3V0ZXIucXVlcnlcclxuICBjb25zdCBwYWdlID0gZGF0YS5CbG9nRG9jdW1lbnQuUGFnZXMuZmluZChwID0+IHAuVGl0bGUgPT09IHBpZCk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XHJcbiAgICAgICAge2dlbmVyYXRlUGFnZShkYXRhLCBtYWluKHBhZ2UpKX1cclxuICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH0iXX0= */\n/*@ sourceURL=C:\\\\Users\\\\sycho\\\\Desktop\\\\Nowy folder\\\\blogtemplate\\\\pages\\\\page\\\\[pid].js */"
    }, void 0, false, void 0, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, this);
};

function handler(req, res) {
  _s();

  var fetcher = function fetcher(url) {
    return unfetch__WEBPACK_IMPORTED_MODULE_4___default()(url).then(function (r) {
      return r.json();
    });
  };

  var _useSWR = Object(swr__WEBPACK_IMPORTED_MODULE_2__["default"])('/api/blogData', fetcher),
      data = _useSWR.data,
      error = _useSWR.error;

  if (error) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "failed to load"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 21
  }, this);
  if (!data) return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: "loading..."
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 46,
    columnNumber: 21
  }, this);
  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"])();
  var pid = router.query.pid;
  var page = data.BlogDocument.Pages.find(function (p) {
    return p.Title === pid;
  });
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_6___default.a.container,
    children: Object(_Layout_layout__WEBPACK_IMPORTED_MODULE_3__["default"])(data, main(page))
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 52,
    columnNumber: 7
  }, this);
}

_s(handler, "/mPM92LW/P1NGaMzsqgbThk7iVA=", false, function () {
  return [swr__WEBPACK_IMPORTED_MODULE_2__["default"], next_router__WEBPACK_IMPORTED_MODULE_5__["useRouter"]];
});

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcGFnZS9bcGlkXS5qcyJdLCJuYW1lcyI6WyJtYWluIiwicGFnZSIsIkltYWdlVXJsIiwiQ2F0ZWdvcmllcyIsImpvaW4iLCJUaXRsZSIsIkNvbnRlbnQiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiZmV0Y2hlciIsInVybCIsImZldGNoIiwidGhlbiIsInIiLCJqc29uIiwidXNlU1dSIiwiZGF0YSIsImVycm9yIiwicm91dGVyIiwidXNlUm91dGVyIiwicGlkIiwicXVlcnkiLCJCbG9nRG9jdW1lbnQiLCJQYWdlcyIsImZpbmQiLCJwIiwic3R5bGVzIiwiY29udGFpbmVyIiwiZ2VuZXJhdGVQYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQU1BLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQVNDLElBQVQsRUFBZTtBQUMxQixzQkFDRTtBQUFBO0FBQUEsNEJBQ0E7QUFBMkIsU0FBRyxFQUFFQSxJQUFJLENBQUNDLFFBQXJDO0FBQUEsMENBQWU7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREEsZUFFQTtBQUFBLDBDQUFlLGFBQWY7QUFBQSw4QkFDSTtBQUFJLGFBQUssRUFBQyxxRUFBVjtBQUFBO0FBQUEsa0JBQWlGRCxJQUFJLENBQUNFLFVBQUwsQ0FBZ0JDLElBQWhCLENBQXFCLElBQXJCO0FBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FESixlQUVJO0FBQTZCLGFBQUssRUFBQyxxQ0FBbkM7QUFBQSw0Q0FBYyxjQUFkO0FBQUEsa0JBQTBFSCxJQUFJLENBQUNJO0FBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGSixlQUdJO0FBQTZCLGFBQUssRUFBQyxvQ0FBbkM7QUFBQSw0Q0FBYyxjQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkEsRUFPQ0osSUFBSSxDQUFDSyxPQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBK0JELENBaENEOztBQWtDZSxTQUFTQyxPQUFULENBQWlCQyxHQUFqQixFQUFzQkMsR0FBdEIsRUFBMkI7QUFBQTs7QUFDeEMsTUFBTUMsT0FBTyxHQUFHLFNBQVZBLE9BQVUsQ0FBQUMsR0FBRztBQUFBLFdBQUlDLDhDQUFLLENBQUNELEdBQUQsQ0FBTCxDQUFXRSxJQUFYLENBQWdCLFVBQUFDLENBQUM7QUFBQSxhQUFJQSxDQUFDLENBQUNDLElBQUYsRUFBSjtBQUFBLEtBQWpCLENBQUo7QUFBQSxHQUFuQjs7QUFEd0MsZ0JBRWhCQyxtREFBTSxDQUFDLGVBQUQsRUFBa0JOLE9BQWxCLENBRlU7QUFBQSxNQUVoQ08sSUFGZ0MsV0FFaENBLElBRmdDO0FBQUEsTUFFMUJDLEtBRjBCLFdBRTFCQSxLQUYwQjs7QUFJeEMsTUFBSUEsS0FBSixFQUFXLG9CQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDWCxNQUFJLENBQUNELElBQUwsRUFBVyxvQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBRVgsTUFBTUUsTUFBTSxHQUFHQyw2REFBUyxFQUF4QjtBQVB3QyxNQVFoQ0MsR0FSZ0MsR0FReEJGLE1BQU0sQ0FBQ0csS0FSaUIsQ0FRaENELEdBUmdDO0FBU3hDLE1BQU1wQixJQUFJLEdBQUdnQixJQUFJLENBQUNNLFlBQUwsQ0FBa0JDLEtBQWxCLENBQXdCQyxJQUF4QixDQUE2QixVQUFBQyxDQUFDO0FBQUEsV0FBSUEsQ0FBQyxDQUFDckIsS0FBRixLQUFZZ0IsR0FBaEI7QUFBQSxHQUE5QixDQUFiO0FBQ0Usc0JBQ0U7QUFBSyxhQUFTLEVBQUVNLDhEQUFNLENBQUNDLFNBQXZCO0FBQUEsY0FDR0MsOERBQVksQ0FBQ1osSUFBRCxFQUFPakIsSUFBSSxDQUFDQyxJQUFELENBQVg7QUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFLRDs7R0FmcUJNLE87VUFFRVMsMkMsRUFLVEkscUQiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvcGFnZS9bcGlkXS42OWEzODkzYzFkM2NmZjQ0MWRlYi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHVzZVNXUiBmcm9tICdzd3InXHJcbmltcG9ydCBnZW5lcmF0ZVBhZ2UgZnJvbSAnLi4vLi4vTGF5b3V0L2xheW91dCdcclxuaW1wb3J0IGZldGNoIGZyb20gJ3VuZmV0Y2gnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uLy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5jc3MnXHJcblxyXG5jb25zdCBtYWluID0gZnVuY3Rpb24ocGFnZSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgPGltZyBjbGFzc05hbWU9XCJwb3N0SW1hZ2VcIiBzcmM9e3BhZ2UuSW1hZ2VVcmx9IC8+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3RIZWFkZXJzXCI+XHJcbiAgICAgICAgPGgzIHN0eWxlPVwiZm9udC1zaXplOiAzNXB4OyBmb250LXdlaWdodDogNzAwOyBjb2xvcjogQChibG9nTW9kZWwucHJpbWFyeUNvbG9yKVwiPntwYWdlLkNhdGVnb3JpZXMuam9pbignLCAnKX08L2gzPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJkeW5hbWljQ29sb3JcIiBzdHlsZT1cImZvbnQtc2l6ZTogMTIwcHg7IGZvbnQtd2VpZ2h0OiA3MDA7XCI+e3BhZ2UuVGl0bGV9PC9oMT5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZHluYW1pY0NvbG9yXCIgc3R5bGU9XCJmb250LXNpemU6IDI1cHg7IGZvbnQtd2VpZ2h0OiA3MDA7XCI+cGFnZS5EYXRlPC9oMz5cclxuICAgIDwvZGl2PlxyXG4gICAge3BhZ2UuQ29udGVudH1cclxuICAgIDxzdHlsZSBqc3g+e2BcclxuICAgICAgIC5wb3N0SGVhZGVycyB7XHJcbiAgICAgICAgbGVmdDogODBweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMjUlO1xyXG4gICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogLTM4MHB4O1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgfVxyXG4gICAgLnBhZ2VIZWFkZXIge1xyXG4gICAgICAgIHdpZHRoOiBjYWxjKDEwMCUgLSA2MHB4KTtcclxuICAgICAgICBwYWRkaW5nLXJpZ2h0OiA2MHB4O1xyXG4gICAgICAgIGhlaWdodDogNTAlO1xyXG4gICAgfVxyXG5cclxuICAgIC5wb3N0SW1hZ2Uge1xyXG4gICAgICAgIGxlZnQ6IDYwcHg7XHJcbiAgICAgICAgd2lkdGg6IGNhbGMoMTAwJSAtIDYwcHgpO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIH1cclxuICAgIGB9PC9zdHlsZT5cclxuICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICBjb25zdCBmZXRjaGVyID0gdXJsID0+IGZldGNoKHVybCkudGhlbihyID0+IHIuanNvbigpKTtcclxuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSB1c2VTV1IoJy9hcGkvYmxvZ0RhdGEnLCBmZXRjaGVyKTtcclxuXHJcbiAgaWYgKGVycm9yKSByZXR1cm4gPGRpdj5mYWlsZWQgdG8gbG9hZDwvZGl2PlxyXG4gIGlmICghZGF0YSkgcmV0dXJuIDxkaXY+bG9hZGluZy4uLjwvZGl2PlxyXG5cclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG4gIGNvbnN0IHsgcGlkIH0gPSByb3V0ZXIucXVlcnlcclxuICBjb25zdCBwYWdlID0gZGF0YS5CbG9nRG9jdW1lbnQuUGFnZXMuZmluZChwID0+IHAuVGl0bGUgPT09IHBpZCk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XHJcbiAgICAgICAge2dlbmVyYXRlUGFnZShkYXRhLCBtYWluKHBhZ2UpKX1cclxuICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH0iXSwic291cmNlUm9vdCI6IiJ9